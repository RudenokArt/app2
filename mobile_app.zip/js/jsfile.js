function F1() 
{
	

var iframe = document.querySelector('iframe');
console.log(iframe.contentDocument)

}
//https://github.com/RudenokArt/app2.git